package Circulos;

import java.util.Scanner;

/*
 * @Autores: Jemmy Puzma 6627
 * 			 Juan Carrera 6605
 * 			 David Llumitaxi 6700
 * 			 Victor Montaluisa 6563
 */
public class cConjuntos {
	int[] A, B, C;
    int tamA, tamB, x = 0;
    Scanner entrada = new Scanner(System.in);

    public void llenarA() {
        System.out.println("\n---------------------------------------------\n"
                + "-   *****   Ingrese el tamaño de A  *****   -\n"
                + "---------------------------------------------");
        tamA = entrada.nextInt();
        A = new int[tamA];

        System.out.println("\n-------------------------\n"
                + "-       llenando A      -\n"
                + "-------------------------");
        System.out.println("Ingrese un numero -> ");
        for (int i = 0; i < tamA; i++) {
            
            A[i] = entrada.nextInt();
        }
    }

    public void llenarB() {
        System.out.println("\n---------------------------------------------\n"
                + "-   *****   Ingrese el tamaño de B  *****   -\n"
                + "---------------------------------------------");
        tamB = entrada.nextInt();
        B = new int[tamB];

        System.out.println("\n-------------------------\n"
                + "-       llenando B      -\n"
                + "-------------------------");
        System.out.println("Ingrese un numero -> ");
        for (int i = 0; i < tamB; i++) {
            
            B[i] = entrada.nextInt();
        }
    }

    public void Union() {
        C = new int[100];

        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < B.length; j++) {
                if (A[i] == B[j]) {
                    A[i] = 0;
                }
            }
        }
        
        for (int i = 0; i < B.length; i++) {
            for (int j = 0; j < A.length; j++) {
                if (B[i] == A[j]) {
                    B[i] = 0;
                }
            }
        }

        System.out.println("\n------------------------\n"
                + "-       A UNION B      -\n"
                + "------------------------");
        System.out.print("A U B = { ");
        for (int i = 0; i < A.length; i++) {
        	
            if (A[i] != 0) {
                System.out.print(A[i]+" ");
            }
        }

        for (int i = 0; i < B.length; i++) {
            System.out.print(" "+ B[i]);
           
        }
        System.out.print(" }");
    }

    public void Interseccion() {
        int s = 0;
        C = new int[100];

        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < B.length; j++) {
                if (A[i] == B[j]) {
                    C[s] = A[i];
                    s++;
                }
            }
        }

        System.out.println("\n-------------------------------\n"
                + "-       A INTERSECCION B      -\n"
                + "-------------------------------");
        System.out.print("A n B = { ");
        for (int i = 0; i < s; i++) {
            System.out.print(C[i] + " ");
        }
        System.out.print(" }");
    }

    public void Diferencia() {
        C = new int[100];
        int k = 0, cont;

        for (int i = 0; i < A.length; i++) {
            cont = 0;
            for (int j = 0; j < B.length; j++) {
                if (A[i] == B[j]) {
                    cont++;
                }
            }

            if (cont == 0) {
                C[k] = A[i];
                k++;
            }

        }

        System.out.println("\n---------------------------\n"
                + "-           A - B         -\n"
                + "---------------------------");
        System.out.print("A - B = { ");
        for (int i = 0; i < k; i++) {
            System.out.print(C[i] + " ");
        }
        System.out.print(" }");
    }

    public void Complemento() {
        C = new int[100];
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < B.length; j++) {
                if (A[i] == B[j]) {
                    B[j] = 0;
                }
            }
        }

        System.out.println("\n----------------------------\n"
                + "-       A COMPLEMENTO B    -\n"
                + "----------------------------");
        System.out.print("A' B = { ");
        for (int i = 0; i < B.length; i++) {
            if (B[i] != 0) {
                System.out.print(B[i]+" ");
            }
        }
        System.out.print(" }");
    }

    public void menu() {
        int opc;
        System.out.println("\n\n------------------------------------------\n"
                + "-        OPERACIONES CON CONJUNTOS       -\n"
                + "------------------------------------------\n"
                + "-    1. Union                            -\n"
                + "-    2. Interseccion                     -\n"
                + "-    3. A diferencia B                   -\n"
                + "-    4. A complemento B                  -\n"
                + "-    5. Salir                            -\n"
                + "------------------------------------------");
        System.out.println("-   Digite su opcion                     -\n"
                + "------------------------------------------\n");

        opc = entrada.nextInt();
        switch (opc) {
            case 1:
                llenarA();
                llenarB();
                Union();
                menu();
                break;
            case 2:
                llenarA();
                llenarB();
                Interseccion();
                menu();
                break;
            case 3:
                llenarA();
                llenarB();
                Diferencia();
                menu();
                break;
            case 4:
                llenarA();
                llenarB();
                Complemento();
                menu();
                break;
            case 5:
                System.exit(1);
                break;
            default:
                menu();
                break;
        }
    }
}
